Oracle WebLogic Server Patch Set Update 10.3.6.0.190716 README
==============================================================

This README provides information about how to apply Oracle WebLogic Server 
Patch Set Update 10.3.6.0.190716. It also provides information about reverting to 
the original version.

Released: July, 2019


Smart Update Details of Oracle WebLogic Server Patch Set Update 10.3.6.0.190716
--------------------------------------------------------------------------

Patch ID - MXLE
Patch Number - 29633432


Preparing to Install Oracle WebLogic Server Patch Set Update 10.3.6.0.190716 
-----------------------------------------------------------------------

- WebLogic Server Patch Set Update (PSU) can be applied on a per-domain basis 
  (or on a more fine-grained basis), Oracle recommends that PSU be applied on an installation-wide basis.
  PSU applied to a WebLogic Server installation using this recommended practice 
  affect all domains and servers sharing that installation.

- Login as same "user" with which the component being patched is installed.

- Stop all WebLogic servers.

- Remove any previously applied WebLogic Server Patch Set Update and associated overlay patches

- Update Java SE (JDK/JRE):
  For users of Oracle JDKs and JVMs, we strongly recommend applying the latest
  Java Critical Patch Updates (CPUs) as soon as they are released. 
  Refer to the following for further information:
  Doc ID 1506916.1 Obtaining Java SE (JDK/JRE) for Oracle Fusion Middleware Products
  https://support.oracle.com/rs?type=doc&id=1506916.1

- If you are running with a security manager and experience java.io.SerializablePermission "serialFilter" permission exceptions,
  then you will need to update the weblogic policy file to include the following line:

   permission java.io.SerializablePermission "serialFilter";

   in the coherence.jar section of the weblogic policy file:

   grant codeBase "file:@WL_HOME/../coherence/lib/coherence.jar" {


Installing Oracle WebLogic Server Patch Set Update 10.3.6.0.190716
-------------------------------------------------------------

 - unzip p29633432_1036_Generic.zip to {MW_HOME}/utils/bsu/cache_dir or any local directory
   
   Note: You must make sure that the target directory for unzip has required write and executable permissions 
         for "user" with which the component being patched is installed.

 - Navigate to the {MW_HOME}/utils/bsu directory.
 - Execute bsu.sh -install -patch_download_dir={MW_HOME}/utils/bsu/cache_dir -patchlist={PATCH_ID} -prod_dir={MW_HOME}/{WL_HOME}

   Where, WL_HOME is the path of the WebLogic home

   Reference: BSU Command line interface
              http://docs.oracle.com/cd/E14759_01/doc.32/e14143/commands.htm


Post-Installation Instructions
------------------------------

a) Restart all WebLogic servers.

b) The following command is a simple way to determine the application of WebLogic Server PSU.

  $ . $WL_HOME/server/bin/setWLSEnv.sh 
  $ java weblogic.version

In the following example output, 10.3.6.0.190716 is the installed WebLogic Server PSU.

      WebLogic Server 10.3.6.0.190716 PSU Patch for BUG29633432

* A note about the weblogic.policy file *

 If you are using a Java security manager (for example, you use -Djava.security.manager to start up WebLogic Server), 
 you must ensure that the codeBase in your policy file points to the location where the patches are installed.
 The policy file is specified by -Djava.security.policy during server startup.
 By default, this is weblogic.policy file and resides in WL_HOME/server/lib, where WL_HOME is the WebLogic Server installation directory.

 This is an example of what should be added to the weblogic.policy file for the installed patches:

 grant codeBase "file:<path-to-WLS-patch-jars>/patch_wls1036/patch_jars/-" {
        permission java.security.AllPermission;
 };

 The default weblogic.policy file is a sample. If you use it, you must modify it. Refer to the following URL for additional information:

 http://download.oracle.com/docs/cd/E17904_01/web.1111/e13711/server_prot.htm


Uninstalling Oracle WebLogic Server Patch Set Update 10.3.6.0.190716
---------------------------------------------------------------

 - Stop all WebLogic Servers
 - Navigate to the {MW_HOME}/utils/bsu directory.
 - Execute bsu.sh -remove -patchlist={PATCH_ID} -prod_dir={MW_HOME}/{WL_HOME}


Post-Uninstallation Instructions
--------------------------------

a) Restart all WebLogic Servers.



Bugs Fixed By This Patch
------------------------

WLS Patch Set Update 10.3.6.0.190716
-------------------------------------------
29585099   THE BACKPORT OF 27057023 CONTAINS AN ERROR
23071867   AGL DS XA AFFINITY NOT HONORED IN SOME TX LOCAL RESOURCE ASSIGNMENT SCENARIOS
29448643   JAVA.IO.INVALIDCLASSEXCEPTION: FILTER STATUS: REJECTED
29671623   CVE-2019-2725
26403575   CVE-2016-7103
29667975   CVE-2019-2824
29726561   CVE-2019-2729
29701537   CVE-2019-2827

WLS Patch Set Update 10.3.6.0.190416
-------------------------------------------
27122975   UDDIEXPLORER.SETUP.GETCOOKIE NPE INCIDENT GENERATION IN CUSTOMER PODS
29140508   CVE-2019-2645
29140551   CVE-2019-2649
29140549   CVE-2019-2648
29140540   CVE-2019-2647
29140516   CVE-2019-2646
26791760   CVE-2019-2568
29140555   CVE-2019-2650
28998139   CVE-2019-2658
16706262   CHANGE PROXY RELATED VARS FROM STATIC VAR TO INSTANCE VAR
28762025   ENSURE THE WLS STATEMENT CACHE IS TURNED OFF IF REPLAY OR ORACLE STATEMENT CACHE ENABLED
28874066   CVE-2019-2615
28891448   CVE-2019-2618


WLS Patch Set Update 10.3.6.0.190115
-------------------------------------------
26624375	NODEMANAGER MEMORY LEAK ON SSL HANDSHAKE FAILURES
17390029 	SUB COORDINATOR URL USES SSL, THEN FUTURE RESOURCE WILL GET INFECTED WITH SAME
19706551	CVE-2019-2395
26353793 	CVE-2019-2398
28110087	CVE-2019-2418 
28626991	CVE-2019-2452 

WLS Patch Set Update 10.3.6.0.181016
-------------------------------------------
20020455	CVE-2018-2902
28140800	Bypass version string checks when non-Oracle JDK is used.
28409586	CVE-2018-3252
28375173	CVE-2018-3245
27988175	CVE-2018-3191
28389003	CVE-2018-3250
28381528	CVE-2018-3248
28381538	CVE-2018-3249

WLS Patch Set Update 10.3.6.0.180717
-------------------------------------------
27819370	CVE-2018-2987
27948303	CVE-2018-2893
18233844	Fixed a datasource hang during rollback if the database was hung
25993295	CVE-2013-1768
27445260	CVE-2018-2935
27934864	CVE-2018-2998

WLS Patch Set Update 10.3.6.0.180417
-------------------------------------------
27043684	Clarify unclear verbiage in a MultiPool connect failure message
26439373	CVE-2017-5645
25987400	Fixed an issue where it wasn't possible to provide indirect transaction propagation between servers that are on different networks
26916941	Fixed an issue that was causing SoapCodec.getOperation() to return null
13421981	Fixed an issue where WLS was failing to collect an automatic thread dump when JDK7 is used
26608537	CVE-2018-2628

WLS Patch Set Update 10.3.6.0.171017
-------------------------------------------
24818026	CVE-2017-10271
26044754	CVE-2017-10334, CVE-2017-10336
19763916	CVE-2017-10152
26144830	CVE-2017-10352
18492020	Fixes an issue with an unexpected RuntimeException if the MaxThreadsConstraint is exceeded

WLS Patch Set Update 10.3.6.0.170718
-------------------------------------------
24533963	CVE-2013-2027
16844206	Updated Jython to recognize Windows 2012
16199510	Fixed an issue with the closure of initial context when creating JMX connection
19687084	Fixed an issue where startNodeManager() would fail if the 'block' argument was set to 'true'
22935339	Fixed an issue where the processor load column in the Admin console displayed N/A with JDK 1.7
21562338	Fixed an issue where a Connection.isClosed() call returned false when the real connection had been closed because of a internal driver condition
17780911	Fixed an issue where very long running statements might cause the pool to incorrectly retract the connection as if it were idle
18084750	Moved the server threads used for processing Oracle FAN messages from the self-tuning thread pool to a Java thread pool
21241854	Fixed a case where a failover callback for an MDS was not called
20463542	Provide an option to allow early-used connections within a global transaction to go back into the pool when logically closed rather than be held to the end of the transaction
13729611	Ensure the WLS statement cache is turned off if replay or oracle statement cache enabled
13337000	Ensure the the init() call for a pool connection includes the original cause if an exception occurs
13516117	Fixed an issue to make seconds-to-trust more reliable
17873235	Fixed a problem where shutting down multiple datasources in a MultiDataSource showed 'not registered' exceptions
16168052	Fixed an issue to make DBMS failure recovery more reliable for MySQL
24618043	Fixed an AGL datasource deadlock window during a RAC node UP event
13861764	Fixed an issue with the deploymentOrder option in weblogic.Deployer
21539098	Fixed an issue where the admin server startup would fail if config.xml was a softlink to a different location
12873489	Fixed an issue to allow a resource adapter to be updated with a deployment plan
13795546	Fixed a performance issue with WLDF Harvester
19194167	Fixed a race condition between JMSSessionPool destroy and create
17608140	Fixed an issue where Path Service UOO routing with admin port configured caused PeerGoneExceptions
22746640	Fixed an issue where Unit-Of-Work messages that arrive after the Incomplete Work Expiration Timer had expired were left pending in the queue
20047315	Fixed an issue where there was an unnecessary wrapper pool shutdown on the connection exception listener due to transaction timeout
22614443	Fixed an issue where Unit of Work (UOW) was not working for non-persistent messages
21748022	Fixed an issue that was causing Out Of Memory on restart-in-place migration
25988919	CVE-2017-5638
25720769	CVE-2017-10137
25823774	CVE-2017-10178
13972486	Fixed an issue where proxy-jroute was not being included with jsessionid for session stickiness
15978104	Fixed an issue where a suspended server would return http 404 instead of http 503
24817968	CVE-2017-10063
16485257	Fixed an issue with namespace prefix when JAXWS is hosted on WebLogic
17900243	Fixed an issue where JAXB was generating an empty namespace for a reference element
16805992	Fixed an issue where two (or more) Web services in the same application with the same Dispatch Policy and with the same context path confused WebLogic Server's handling of Work Managers
17779642	Fixed an issue where a stuck thread would occur when enabling the mimepull cleanup thread
20243939	Fixed an issue where a Stackoverflow error associated with soap message would occur if the message had white spaces after Soap Body Element 
16498923	Fixed a memory leak issue in the parsers that were not being properly cleaned up
13645544	Fixed an issue where the CDATA section in a text filed was being ignored
20671165	CVE-2016-3473
14763918	Fixed an issue where multiple stuck threads would occur at WLSProvider$ServiceDelegate.getPort 
22261241	Fixed an issue where NoClassDefFoundError would occur when using <wldeploy> task to deploy an application to a JACC-enabled WLS server
25743005	CVE-2017-10147
25743025	CVE-2017-10148

WLS Patch Set Update 10.3.6.0.170418
-------------------------------------------
24297731	CVE-2016-1181
23099318	CVE-2017-3506

WLS Patch Set Update 10.3.6.0.170117
-------------------------------------------
16685491	By default, HTTP header does not send information like ""X-Powered-By: @Servlet/2.5 JSP/2.1"".
25029531	Application breaks after applying October 2016 PSU due to multipart form-data.
23733891	CVE-2017-3248

WLS Patch Set Update 10.3.6.0.161018
-------------------------------------------
19576633	CVE-2016-5488
23732201	Fix For 23732201
23004029	CVE-2016-5531
22836557	CVE-2015-7501
23103220	CVE-2016-5535
23642257	WebLogic 12.1.2.0.8 patch breaks Custom Work Manager
23735210	JMX connection over IIOP broken on SRC103600FABP with JDK6 and JDK7

WLS Patch Set Update 10.3.6.0.160719
-------------------------------------------
20229977	WLS lacks privileged block WEBLOGIC.APPLICATION.IO.MERGEDDESCRIPTORFINDER
15869805	12.2.4: Exception: Registered more than one instance with the same object.
19947189	CVE-2016-3445
22666897	CVE-2016-3505
17252759	PSR:PERF:WLS CLASSLOADER leak with simple servlet app.
14248155	java.security.AccessControlException: access denied (java.util.PropertyP occurs if a webservice client is calling a webservice vis ssl
14174659	Issue with EJB base webservice when System Filter are configured ,the System Filters are not used.
18945422	Sometimes getting WLS server status is failed due to AssertionError.
13951275	For an EJB based JAX-WS webservice: To protect both the WSDL and the webservice methods the following shoul The security information can be configured only through the webservices descriptor weblogic-webservices.xml and without an security in the ejb descriptors. If the security information is added using ejb descriptor's ejb-jar.xml/RolesAllowed annotation and weblogic-ejb-jar.xml. The principal names mapped to the role names in the ejb descriptor's sh map to the global roles (weblogic-webservices.xml uses the global roles be configured at the server level. The security can be configured only through the ejb descriptors and the role configuration do not need to be added to weblogic-webservices.xml. For an EJB based JAX-WS webservice: To protect both the WSDL and the webservice methods the following shoul The security information can be configured only through the webservices descriptor weblogic-webservices.xml and without an security in the ejb descriptors. If the security information is added using ejb descriptor's ejb-jar.xml/RolesAllowed annotation and weblogic-ejb-jar.xml. The principal names mapped to the role names in the ejb descriptor's sh map to the global roles (weblogic-webservices.xml uses the global roles be configured at the server level. To protect just the webservice methods (when there is no need to protec The security can be configured only through the ejb descriptors and the role configuration do not need to be added to weblogic-webservices.xml.
20333386	WLS lack privileged block while connecting to server during session replication.
19790693	Needs privileged block while accessclassinpackage.com.sun.proxy
23107300	CVE-2016-3586
23099223	CVE-2016-3510

WLS Patch Set Update 10.3.6.0.160419
-------------------------------------------
14236278	CVE-2016-0675
21912256	CVE-2016-0696
22049932	CVE-2016-3416
22339918	CVE-2016-0638
14396863	Fix for 14396863
22498352	CVE-2016-0670
21519519	CVE-2016-0688

WLS Patch Set Update 10.3.6.0.13
---------------------------------------
22200491	CVE-2016-0572
21615827	CVE-2016-0464
14324000	WebLogic incident directories are created with read only permissions on group user.
21516492	CVE-2014-0107
22200523	CVE-2016-0573
21756751	Fix for bug 21756751.
22200594	CVE-2016-0574
22200449	CVE-2015-4852
22247869	CVE-2015-4852
21495475	CVE-2015-4852
22248079	CVE-2016-0577
22175246	CVE-2015-4852

WLS Patch Set Update 10.3.6.0.12
---------------------------------------
18971476	After applying patch 18040640 (WLS PATCH SET UPDATE 10.3.6.0.8) on WebLogic Server 10.3.6, Web services with a POST method request, when tested using the Weblogic Test Client, produce the following error: NetUI Error - Invalid URL. Please check the input WSDL URL.
20181997	WebLogic Server 10.3.6.0.11 PSU Patch Smart Update Patch ID: YUIS
20206879	CVE-2015-4744
20814890	Fix for bug 20814890.
20906638	CVE-2015-2623
20985893	Fix for bug 20985893.
21069524	Fix for bug 21069524.
21169554	There is a configuration issue during FA preflight generation.

WLS Patch Set Update 10.3.6.0.11
---------------------------------------
10169939	In rare cases, a firewall-induced hanging of JDBC rollback() calls may occur.
11781879	The following error occurs: IllegalStateException: HttpSession is invalid 
12756007	WebLogic Server fails to start when the listenAddress fails to resolve.
12977335	SAF replyTo destinations do not work correctly if they contain a ""/"" character in their JNDI names.
13425354	ClientProviderBase discards the provider class loader and causes a ClassNotFoundException error.
13443170	The WLDF Dashboard hangs when a WLDF configuration is deployed to the Administration Server that uses MBeans from the Domain Runtime MBean Server.
13528666	JMS wrappers with a foreign JNDI provider are not registering a connection listener exception when connection health checking is disabled.
13605855	WebLogic Server authentication is intermittently delivering a valueUnbound() notification.
13636316	The reliance on a JDBC abort() function to close connections needs to be lessened.
13688690	JMSServerRuntimeMBean is not reporting the correct HealthState information for JMS servers from WLST.
13724471	Deadlock occurs during logout processing.
13797019	There are session data and session context issues causing deadlock.
13811688	A session invalidation error occurs.
13865212	A java.lang.IllegalArgumentException error occurs when registering PersistentStoreRuntimeMBean.
13916854	JDBC pools are not automatically resuming.
13921016	Starting Node Manager does not complete if a Managed Server is hanging.
14158072	Connection timeout and explicit connection termination do not work if IIOP over HTTP is used with a WebLogic Server thin client.
14170241	Stuck threads are reported when prefetch mode is enabled for synchronous consumers.
14170469	There are JMS session close/stop issues.
14174857	The maximum file size allowed for WebLogic server and domain logs was increased from 64MB to 2GB.
14203206	Pool operations become very slow once an adapter's cleanup is slow.
14195479	ServiceMigrationDataRuntimeMBeans and MigrationDataRuntimeMBeans accumulate in a cluster master server instance and an Administration Server (to be able to see a history of migrations) and are not purged until they are shut down.
14404715	The following error occurs when sending a message:
		weblogic.jms.common.JMSException: could not find Server null
14545078	When two domains with three clusters have MDBs deployed and connected to a remote UDQ deployed on these domains, the MDBs will show inconsistent consumer counts if the domains are restarted at the same time.
16197157	When the Resource Manager on the EIS side shuts down, XAResource causes an XAException with error code RMFAIL and the XAResourceDescriptor of the connection pool becomes unhealthy.
16432556	Too many threads are created under medium load.
16733584	Excessive DDHandler SAF member updates occur during server startup.
16759418	When WebLogic Server receives many requests at the same time, the working queue overflows and MaxThreadsConstraint.add() causes a RuntimeException which stops the ExecuteThread.
16796909	The self-tuning mechanism is disabled due to numerous consecutive Suspicious conditions in IncrementAdvisor. As a result, the thread count is not adjusted for a long period of time.
16851678	A java.io.IOException error is logged on the Administration Server when starting a Managed Server.
16942173	The first message in a SAF agent for a specific endpoint is lost on retry when using a Uniformed Distributed Destination and Exactly-Once QOS when the endpoint connection is lost during a forward attempt.
16985122	A session leak issue caused by the WebLogic Server API weblogic.servlet.security.ServletAuthentication.invalidateAll occurs.
17005283	A NullPointerException may occur when new execute threads are added to the thread pool during server startup.
17069175	The WebLogic Server Administration Console may hang temporarily when displaying the server status page while one or more Managed Servers are shutting down. This issue depends on the TCP timeout setting at the OS level.
17070169	A synchronization issue with WatchManager is causing performance issues.
17157465	If multiple Work Managers share a common maxThreadsConstraint, then the number of threads executing work from these Work Managers keeps growing and prevents other work from executing.
17287466	Durable subscribers are not deleted when a versioned application is removed.
17317455	CVE-2015-0449
17322851	A NullPointerException is seen in the WebLogic Server Administration Console on the Web services monitoring page when starting the Administration Server and a clustered Managed Server with -Dweblogic.wsee.skip.async.response=true.
17354363	Thread contention occurs with CDSRemoteProxy.peerGone().
17439835	When a Web service with a JMSTransport application is stopped/undeployed, the CustomHostNameVerifier is called five times if the HostNameVerification check fails.
17461357	When creating a data source using the Administration Console for another database type (not one of the known types), the generated data source descriptor does not contain user=username in the connection properties.
17658152	A running XA resource may be reported as unregistered.
17721032	A Managed Server fails to start with a IndexOutOfBoundsException error.
17722626	Primary sessions leak when a user calls getSession during the session invalidation.
17759384	Each deployment leaves temporary files on disk that are not deleted because of their content.
17776316	SAF remote destination JNDI names are missing after a server restart.
17780729	A JDK wild card query may cause a MaxMessageSizeExceededException error.
17911980	Calling a ServerRuntime instance from an external JMX client or the WebLogic Server Administration Console and starting a Managed Server concurrently may cause all Managed Server applications to display in NEW state with a failed health check.
17935963	A Managed Server fails to start when the administrator enforced two-way SSL only SSL port is enabled for the Administration Server.
18073982	A connection failure error occurs on 12c servers in German Windows while starting Managed Servers.
18106382	A NullPointerException occurs when trying to create an EJB timer.
18164066	SAF is not load balancing to other available members when one member is down.
18231133	An Active GridLink (AGL) affinity failure may occur.
18349378	The session reference count for a memory session is incorrect.
18430781	A java.lang.ClassCastException is observed in the cluster logs.
18912482	A java.lang.ClassNotFoundException error occurs when looking up a generic EJB.
19637463	WebLogic Server 10.3.6.0.10 PSU Patch Smart Update Patch ID: 12UV
19907066	CVE-2014-3566
20302117	The -Dweblogic.security.SSL.minimumProtocolVersion flag is now supported in Node Manager.
20523619	Calling a ServerRuntime instance from an external JMX client or the WebLogic Server Administration Console and starting a Managed Server concurrently may cause all Managed Server applications to display in NEW state with a failed health check.
20825149	CVE-2014-3566

WLS Patch Set Update 10.3.6.0.10
---------------------------------------
18436016	CVE-2014-6569
19182814	WebLogic Server 10.3.6.0.9 PSU Patch Smart Update Patch ID: FSR2
19287842	CVE-2013-2186
19287874	CVE-2013-2186
19596460	Redeploying an EJB application which included the entity bean whose remote JNDI and local JNDI were both specified could cause a BEA-000124 error.
19600486	The <max-request-parameter-count> attribute is missing from the com.oracle.cie.config-wls-schema_10.3.6.0.jar file.
19730967	The system property weblogic.data.canTransferAnyFile did not allow some files to be transferred, but now will allow any file to be transferred.
19942900	There is a regression issue that does not allow the Deployer role to deploy applications.

WLS Patch Set Update 10.3.6.0.9
--------------------------------------
17425750	XA commits fail due to an unregistered resource.
18040640	WebLogic Server 10.3.6.0.8 PSU Patch Smart Update Patch ID: T5F1
18691894	CVE-2014-0114
18859387	CVE-2014-4256
18968900	CVE-2014-6534

WLS Patch Set Update 10.3.6.0.8
--------------------------------------
17311996	CVE-2014-4201
17312710	CVE-2014-4202
17572726	WebLogic Server 10.3.6.0.7 PSU Patch Smart Update Patch ID: FCX7
17859691	CVE-2014-4217
17884269	CVE-2014-4241
17884290	CVE-2014-4210
17930681	CVE-2014-4242
18169911	CVE-2014-4253
18170928	CVE-2014-4256
18223937	CVE-2014-4267
18224308	CVE-2014-4255, CVE-2014-4254
18224766	CVE-2014-2479
18230569	CVE-2014-2481
18230581	CVE-2014-2480
18230607	CVE-2014-2470

WLS Patch Set Update 10.3.6.0.7
--------------------------------------
8673503		In earlier versions of WebLogic Server, the Administration Console pages that displayed users and groups for a security realm were limited to only the first 1,000 entries that met the search criteria. This console limitation has been increased in this release to support displaying up to the first 50,000 entries. Administration Sever memory availability and the security provider configurations may impose additional constraints on these results.
12717057	The weblogic.net.http.AsyncResponseHandler is not properly relaying error information to the user. The AsyncResponseHandler may have an internal error handling the connection and rather than that error being logged or given to the user, the weblogic.net.http.HttpURLConnection class sees the internal error and automatically retries the connection. This means that errors handling the initial connection are ignored and a subsequent connection is made synchronously.
12948850	If WebLogic Server is running on a 64bit JVM on the Solaris platform, the following error occurs:
		cannot load library 'stackdump': java.lang.UnsatisfiedLinkError: no stackdump in java.library.path
12830851	There are multiple MBean registrations for the same ObjectName.
12986335	WebLogic HTTP handlers cannot read the responses when a server instance sends more than three HTTP100-continue responses.
13067536	An HTTPS request is sent twice when AsyncResponseHandler is used for a Keep-Alive disabled SSL server.
13513740	A GlassFish JAXP implementation needs added only on the AIX platform for JSTL.
13844661	The JAX-WS Web service is not decoding the quote-printable attachments.
13875685	The JMS servers page in the Administration Console shows blank values in the Current Server and Health columns even though JMS servers are known to be up and running.
13888100	The jsp_servlet folder is removed during WebLogic Server shutdown.
14174803	WLST's startNodeManager now supports a jvmArgs that is a comma-separated list of JVM parameters.
14644893	The @OneWay Web service method does not return a response directly.
14777804	A java.lang.IllegalStateException occurs in the ClientIdentityRegistry.getRequiredClie() method.
14833661	Web service performance issues occur in SAML because Class.forName is used every time a new instance of SecurityPolicyAssertionInfoFactory is created.
15872739	A memory leak based on weblogic.jsp.internal.jsp.tag.TagFileTagInfo objects occurs.
15879401	Domain runtime JMX layer should cleanup connections on IOExceptions and try to reconnect to the Managed Server.
15917682	A memory leak occurs when starting and stopping a Web application-based Web service.
16290362	Log file corruption may occur during rotation.
16448282	A Web service fails to deploy when schema validation is enabled.
16504525	EndPointImpl leaks HeartbeatKey and DisconnectListener if it is used from an MBean with IIOP.
16530704	There is an interoperability issue between WebLogic Server 10.3.4, 10.3.5, and 10.3.6 and 8.1 distributed destinations mapped through a foreign JMS server configuration.
16794193	AppDeploymentRuntimeMBean.getModules needs to be optimized for better performance.
16857433	The processor load in the Administration Console is showing as 100% for idle WebLogic Server processes.
17071663	WebLogic Server 10.3.6.0.6 PSU Patch Smart Update Patch ID: BYJ1

WLS Patch Set Update 10.3.6.0.6
--------------------------------------
11820051	WebLogic Server JAX-RPC client fails with the following exception when given WSDL contains partnerLinkType element: javax.xml.rpc.JAXRPCException: Failed to parse WSDL.
12953944	An incorrect message is displayed in the Administration Console when dumping thread stack while using Sun JDK7.
12986096	mark()/reset() for weblogic.utils.http.HttpChunkInputStream does not work as expected.
13455973	RegexPool spins on HashMap/ArrayList or a ConcurrentModificationException occurs.
13572948	When modifying a servlet, instead of using the parameter <resource-reload-check-seconds>, the <page-check-seconds> parameter is used to refresh the servlet.
13688111	Upload of large files (>=250MB) during deployment fails.
13778555	When an EJB bean class uses a covariant return type of the method declared in the business interface, the EJB sometimes will not be deployed because a ComplianceException occurs saying that the return type does not match.
13986212	The following JDNI MDB exception occurs when a migratable target uses the restart-in-place mechanism of a JMS service in case of JDBC store failure: java.lang.IllegalArgumentException: Registered more than one instance with the same objectName.
14082307	SAF imported destination JNDI names are sometimes missing after a server restart.
14154043	Cluster group messages may be processed in the wrong order. This can cause a memory leak of BasicServiceOffer objects.
14222753	Scheduling a lot of timer listeners may cause huge lock contention on weblogic.timers.internal.TimerThread.
14261891	A NullPointerException occurs when WebLogic Server loads a certain Web application.
14337022	A problem occurs with LLR multi data sources and LLR data sources which causes a server to start in ADMIN state.
14470240	A NullPointerException or NoSuchObjectException occurs during undeployment of a versioned EJB application.
14477461	A NullPointerException or AssertionError occur from RMI related classes ClusterableRemoteRef and ServerRequest under heavy load.
14521870	OOM occurs when invoking stateful session beans, especially in the case where the bean has a large state.
14578710	Cannot monitor UDD from application deployment module monitoring page.
14623004	getBodyLength() returns zero if the message is compressed.
14738954	When starting wlst.sh on some particular machines, the following exception occurs from jython-modules.jar/Lib/javashell.py: IndexError: index out of range: 0.
14784269	When restarting a system resource the following message is displayed: ""All of the servers selected are currently in a state which is incompatible with this operation or not associated with a running Node Manager or you are not authorized to perform the action requested. No action will be performed.""
14839946	Stopping an application with a WAR based Web service does not remove a WebServiceRuntimeMbeanImpl reference. This causes a memory leak as the classloaders are not removed.
15972018	JCA connections are destroyed and recreated under heavy load on a highly threaded server with a small pool configured.
15979318	Unable to view UDD module information from application deployment monitoring page if the application name has a version delimiter in the name.
16044387	Stop and start of an EJB Web service with WebServiceRef annotation causes an IllegalArgumentException error.
16063328	JTARuntime getTransactionLogStoreRuntimeMBean() fails when JDBC TLOG is defined.
16080294	A NullPointerException occurs during session replication in an identity provider domain.
16172812	A memory leak occurs when a Web application based Web service starts and stops.
16180221	Cannot control an application that is versioned using the format <app name>#<version> for the application name instead of specifying the name with a name argument and the version with a version argument (<app name>#<version> format not accepted).
16192004	Memory growth was observed during cache deploy/undeploy operations in a loop.
16363439	WebLogic Server's Certicom SSL implementation does not support protocol versions greater than TLS1.0, but it falls back to TLS1.0 when it receives a later version in the SSL handshake.
16441288	CVE-2013-3827
16619891	WebLogic Server 10.3.6.0.5 PSU Patch Smart Update Patch ID: L51R
16866427	When no HTTP Basic header is sent by the client, OWSM sets the status to 401 Unauthorized (challenge) but the client receives a status code of 200 (with the request message).
17386939	A ClassCastException occurs when restarting the JPA visitor's application in a cloud environment.

WLS Patch Set Update 10.3.6.0.5
--------------------------------------
9893784	WebLogic Server Administration Console logout does not follow SSO logout guidelines.
12333627	wlsifconfig.sh script does not work+D12 well on Solaris.
13029650	When an application fails to activate while starting WebLogic Server and is undeployed after starting WebLogic Server, temporary files are not removed.
13101234	Usage of self-referencing tag in a tag file causes infinite recursion during JSP compilation and the server crashes with StackOverflow.
13243584	All threads of a server may become stuck due to a circular linked list of chunks.
13323399	Usage of self-referencing tag in a tag file causes infinite recursion during JSP compilation and the server crashes with StackOverflow.
13335517	When using com.ibm.db2.jcc.DB2XADataSource driver, if there is an outstanding result set, when delist with TMSUSPEND is called the result set can no longer be retrieved and a SQLException occurs.
13339004	Java level deadlock occurs between weblogic.jms.common.CDSLocalProxy.addToLDMapList() and weblogic.jms.common.CDS.startPolling().
13541872	Symbols with code positions between 128 and 159 in the Windows-1252/CP1252 encoding do not print correctly when accessed with request.getParameter().
13556860	Server state cannot switch back to ""Running"" after JTA recovers the JDBC TLOG store.
13930786	A deadlock may occur between weblogic.cluster.singleton.ReplicatedSingletonServicesStateManager.createRecoverMessage() and weblogic.cluster.singleton.ReplicatedSingletonServicesStateManager.sendGroupMessage() during failover.
13966362	MDB with runAsSubject defined fails with NoPermissionException when anonymous JNDI lookups are disabled on the domain.
14049600	When patch for bug 12822180 has been applied to a system, custom unicast messaging channels (configured with cluster-broadcast-secure protocol) are not creating SSL connections.
14097743	WLST does not pick up custom modules unless they are in a directory named ""lib"" in the user's current working directory.
14099018	Performance issues occur when using message time to live due to lock contention.
14109594	An NPE exception occurs at MDListener.execute and consumer count does not go to zero even after MDB is underplayed.
14114017	Repeated JTA migration failed-back attempts leak GenericBeanListeners and store connection MBeans.
14146417	Java level deadlock occurs between weblogic.messaging.kernel.internal.QueueImpl and weblogic.jms.frontend.FEConnection.
14225559	Cookie based single sign-on does not work when cookie-path is set.
14228675	When -Dweblogic.RjvmIdleTimeout=<value in milliseconds> is set on a client, the RJVM connection will be reaped at the end of <last time connection was used> + idleTimeout value.
14239574	GC performance may be negatively impacted in a heavy timer used environment.
14268667	Coherence servers are restarted in the wrong node in shared NFS domains when Node Manager is restarted.
14276072	Messaging bridge Java level deadlock occurs between weblogic.jms.adapter.JMSBaseConnection.close and weblogic.connector.outbound.ConnectionHandlerBaseImpl.destroyConnection.
14334824	When a database is hanging and suspended, the code will no longer try to recreate connections immediately.
14355039	After successful migration, server cannot be started if the original Node Manager is down and an available Node Manager exists for the candidate machine.
14377549	Ignorable <BEA-002936> message is sometimes raised too frequently in log files.
14476992	After successful migration, server cannot be started if the original Node Manager is down and an available Node Manager exists for the candidate machine.
14482558	When diagnostic image is triggered frequently by manual operation on UI/Console/WLST or by a watch rule, it is possible to have continuous classes loaded which can cause a memory leak.
14547194	Partially redeploying a JSP page on a production domain does not work.
14597598	The startNodeManager WLST command fails in Solaris 64bit environment.
14629058	When a rollback is called for an XAResource that is deployed in more than one server that participates in the global transaction, the rollback fails with a NullPointerException and the number of connections in the pool keeps increasing until it runs out of connections.
14659661	Validation error occurs when configuring singleton-uri in weblogic-application.xml.
14747231	ChunkedInputStream.read() causes ArrayIndexOutOfBoundsException in some situations.
14826542	-Dhttp.nonProxyHosts does not work correctly when using an upper case hostname.
14830451	An exception occurs when requesting a connection from a GridLink data source from within a global transaction if there is a transaction affinity context associated with the global transaction and there are no available connections to the specific RAC instance and such a connection cannot be created.
15839280	Queue length count increases over time and never reduces.
15941020	NullPointerException may be encountered during cluster startup when unicast messaging is configured with cluster-broadcast-secure protocol.
15990943	Pageable current counts are higher than possible.
16023814	Non-Oracle LLR data sources may fail to create a log table.
16083651	WebLogic Server 10.3.6.0.4 PSU Patch Smart Update Patch ID: D33T
16104758	LifecycleShutdownSequenceTest fails with IllegalStateException error after server is shut down and when getting a message through messageListeners.
16176831	WLST fails to start the server using the startServer() command when running it with JDK7u10 through JDK7u13.
16199781	JMS server HealthState not reflecting persistent store HealthState.
16358443	When viewing JFR recordings, may see large numbers of JVM generated system processes events and less of other events.

WLS Patch Set Update 10.3.6.0.4
--------------------------------------
12879342	weblogic.appc generates duplicated methods for EJB wrapper classes.
12943601	Fixed a case where a console test of a Gridlink data source gave a false OK.
13029954	weblogic.corba.cos.transactions.RecoveryRegistrar scheduling work repeatedly during server startup resulted in OutOfMemoryError and <BEA-002911> <Work Manager weblogic.kernel.System failed to schedule a request errors.
13038998	Threads can get stuck in weblogic.utils.io.ChunkedOutputStream.getSize.
13339111	Multi-threaded MBean invocation could fail with IllegalStateException: Cannot register two instances of WorkContextAccessController.
13642828	Under very high concurrency, some jobs are lost.
13786376	The durable subscriber ""Active"" status is incorrect after MDB redeployment.
13836819	When native IO and JSSE are enabled on a Windows platform, NTSocketMuxer is used. If incoming data is too big and it consumes 100% CPU, you have to restart the server to recover.
13846938	When a JCA bridge adapter is deployed to a cluster, distributed transactions will fail with XAER_PROTO and XAER_NOTA exceptions. Messages will fail to be sent.
13877154	RMERR occurs on bridge recovery for foreign JMS resources.
13900234	WebLogic Server not able to access JMS file store.
13916756	Transaction propagation will fail if a transaction coordinator object is propagated under an application context on IIOP and then the application is restarted.
13961904	Diagnostics store is initialized only once during a server run, which normally happens when the diagnostics system service initializes. In that case, the diagnostics store is initialized with configured parameters. If the diagnostics store is implicitly accessed during application deployment, it may be initialized without configured parameters, potentially resulting in sub-optimal operations. The fix ensures that the diagnostics store is initialized early in the server startup with configured parameters.
14030073	Work Manager capacity is not constrained in AsyncResponseHandler.
14141508	A Managed Server disconnected from the network is not able to reconnect to the Administration Server after bringing back the Manager Server to the network.
14162804	Fixed a possible NPE during data source module updates.
14182161	Fix for bug 14182161.
14214377	Fixed a problem that occurred when using the JTS driver in a clustered data source.
14217465	A ConcurrentModificationException occurred when an application was deployed to a large cluster.
14305906	An OracleXAException exception occurs during testing of the XAConnection. Later the XAResource will unregister and subsequent transaction work will fail with XAER_RMFAIL.
14324689	The following ClassCastException error may occur when accessing a remote data source using T3S protocol:
		java.lang.ClassCastException: weblogic.jdbc.common.internal.RmiDataSource cannot be cast to weblogic.rmi.extensions.server.RemoteWrapper
14330170	At two-phase commit time, when a JNDI lookup for a SubCoordinator occurs, we will go into a timed wait. The wait is not interrupted so the thread waits until the time expires before making transactions time out.
14331585	The RMI related classes ClusterableRemoteRef and ServerRequest, under heavy load, cause a NullPointerException or AssertionError.
14489760	When using side-by-side deployment and restarting Managed Servers in a cluster, WebLogic Sever only returns ""HTTP status 404"".
14506522	NullPointerException or AssertionError occur when RMI related classes ClusterableRemoteRef and ServerRequest are under heavy load.
14527104	The lock file is always removed at Node Manager startup when a domain directory is shared among multiple nodes and CrashRemoveryEnabled is false and the target server is launched by a different node from the current Node Manager node.
14595754	When initializing multiple WLSTInterpreters in parallel, errors could occur during initialization of the WLST help. This caused issues with FMW provisioning and starting of servers in the domain.
14684791	There was a problem with the JDBC store using Oracle BLOBs after DBMS failover.
14736139	WebLogic Server 10.3.6.0.3 PSU Patch Smart Update Patch ID: HYKC
14742729	When a domain directory was a symbolic link, WebLogic Server would translate the symbolic link and put the physical location in the domainlocation.properties file instead of the symbolic link. This file is used by OCM to determine the location of WebLogic Server domains on the machine.
14809365	There is a problem with HTTP authentication for WebLogic Server Web services stack.
15865825	By default, if <auth-method> in the WEB-INF/web.xml file is either configured as BASIC or not configured, WebLogic Server web containers will authenticate a user if there's an ""Authorization"" header in the HTTP request. However, this authentication by the web container will cause issues for cases in which some Oracle products authenticate by themselves.
15973456	CVE-2013-1504
16030408	CVE-2013-2390
16544926	WebLogic Server fails to start with JDK 1.6.0_39 or higher releases if the Java Security Manager is enabled.

WLS Patch Set Update 10.3.6.0.3
--------------------------------------
9365773		Even if a multi data source was configured for automatic migration, the multi data source itself was not used to get a connection object.
11781863	A connection would be marked as closed before the CLOSE message was sent to the other side.
11787233	If a manual migration is performed on an existing server after restarting the Node Manager, Node Manager is not unbinding IP from the machine it is migrating from.
12661992	If a server fails and it is enabled for whole server automatic migration, Node Manager automatically restarts it. When both the server and the cluster set candidate machines, server settings precede cluster settings, and Node Manager should restart the servers according to the preferred order.
12880112	This issue was introduced by some change in 1211 where the order of class loading changed, causing an existing static reference to be null. If the customer picks up a patch with only the problem change and without this change, they will see the following error when starting the server:
		Unable to load performance pack. Using Java I/O instead. java.lang.NullPointerException.
13057330	Fixed a possible NPE when multiple threads were accessing a pool that was refreshing connections.
13113943	When redirecting with an absolute URL, WebLogic Server does not reset the request object. This causes any request attributes to remain in memory.
13335847	ReplicatedSessionData.setInternalAttribute causes NPE during stress test.
13345336	Creating InitialContext with wlclient.jar when a proxy server is inbetween the client and the WebLogic Server instance is causing CORBA exceptions.
13351178	Node Manager will no longer log socket closure events by default.
13384191	There was a memory leak of HTTP sessions.
13424251	Singleton services are being registered on a server belonging to another cluster in same domain when targeted to migratable target.
13428678	There is a policy tag missing in the JAX-WS service in the generated WSDL.
13497565	Java level deadlock results in hang at JMSSession.close().
13525568	The messaging bridge is having difficulty refreshing connections after a connection is lost.
13536666	An issue with Certicom SSL cipher suites occurs when enabling an explicit set of cipher suites.
13593954	Under sustained load, nearly all execute threads may move from 'Active' pool to 'Standby' pool for approximately 4 seconds, which grinds throughput to a halt during that period.
13643068	Issue when calling the close method on the weblogic.deploy.api.tools.SessionHelper after saving the policy changes to the Web services. There is no debug option to find out whether SessionHelper.close() is called or not.
13652678	In a clustered environment, when multicast is used, sometimes one Managed Server goes into high CPU as it processes a cluster message from another Managed Server over and over again.
13656558	Additional fix for CVE-2011-5035
13741230	The customer would previously always see the healthiest state possible from the server when making use of the ServerRuntime.getOverallHealthState method.
The correct behavior is to return the worst state that is found. The customer may now notice that they see more warnings or information about possible errors in the server or application states.
13799448	Virtual directory paths were not resolving correctly for virtual directories in exploded format.
13826672	If a null ObjectName was passed in a JMX getAttribute call to WebLogic Server, then an NPE exception would be returned.
13829888	The customer would occasionally see clients fail or hang trying to send or read HTTP messages from the WebLogic Server HTTP client stack. This problem was very intermittent and difficult to diagnose without any direct error messages or pointer to the root problem.
13842172	Node Manager crashes after application of patch 12407849.
13959283	The SOAPbody content cannot be extracted if it contains more than one node.
14013341	Stuck threads occur at JMSSessionPoolTester.close(). Corrects hangs on session/connection close()/stop() and onException().
14055280	Changing subdeployment target on a non-shareable topic subscription fails with JMSException: Error creating consumer Queues subscribed to topics use the same quota.
14100309	Setting a value for StateCheckInterval in nodemanager.properties did not take effect.
14118450	If a Managed Server becomes unavailable in the middle of an activate call from WLST, then a WLSTException occurs instead of the operation succeeding. The WLSTException contains a message that WebLogic Server was not able to contact the server and the deployment has been deferred.
14159653	Profiles showed that ServerRuntime.getListenAddress (primarily in host name resolution) was taking a lot of time. This was not always the case, so could be related to a DNS issue.
14230544	java.lang.IllegalArgumentException occurs when restarting a server after defining CapacityConstraint with a default count value of -1.
14255420	In some cases, a NullPointerException may occur during an SSL handshake.
14273523	High-availability database leasing fails silently when database table for leasing is not created.
14331441	Daemon threads from the Work Manager are always named the same way.
14331527	WebLogic Server 10.3.6.0.2 PSU Patch Smart Update Patch ID: MYFD
14338138	Cannot start and stop a Web application when configuring Work Manager.
14398056	context.getAttribute(""javax.servlet.context.tempdir"") does not return the value specified in weblogic.xml for the temporary directory.
14456212	SessionData.remove() has the potential for memory leaking in the SessionLogin object.

WLS Patch Set Update 10.3.6.0.2
--------------------------------------
11818904	A Message Drive Bean (MDB) that is in an inactive state cannot be resumed.
12698743	ClientRuntimeDescriptors are not being refreshed correctly.
12822180	Cluster instability is seen when using unicast due to threads appearing to be stuck when writing unicast messages to other servers.
12973216	A cluster member that downloaded a cluster JNDI tree from another member in the cluster could receive a message containing the same objects that have been sent as the cluster JNDI tree from that same member.
13070249	In some cases, a failed deployment returns no information about the underlying problem (root cause) with the WAR. When there is an XML parsing error, the full stack trace is included in the returned javax.enterprise.deploy.spi.status.DeploymentStatus. When there is a classloading problem, however, no information is returned, just the name of a wrapping exception.
13109327	In some situations, such as when a watched MBean instance is unregistered, a WLDF watch rule continues to trigger and does not observe the configured Alarm reset period for the Watch. This occurs only when a WLDF watch rule is configured with an automatic reset alarm.
13248759	A deployment might be rejected when done simultaneously with another deployment.
13255059	Authentication does not work when using a not signed X509 token.
13349651	If there are many files in the config directory, and many Managed Servers have been configured, Managed Servers either take a while to complete the startup process or an OutOfMemoryError occurs on the Administration Server .
13367913	A NullProtectionError occurs during server startup when starting the server with the -Dweblogic.t3.ConnectTimeout system property.
13372349	Data source configuration for the IBM DB2 driver in the Administration Console does not include Host and Port.
13372449	An Oracle RAC failover occurs when using the BLOB Data Definition Language (DDL) option. The full efficacy of the fix in bug 13372449 requires the application of the proactive patch for bug 14684791
13415672	There is a delay in completing a Message Drive Bean (MDB) suspend operation.
13455536	Threads become stuck while waiting on an RMI response in FEConnection.stop() from unresponsive back end.
13509674	A memory leak occurred on the Administration Server due to repeated startup and shutdown of a Managed Server.
13525669	CVE-2011-1411
13536596	Unable to create a data source of type 'Other' in the Administration Console.
13582740	When running WebLogic Server with a policy file, the compiler fails to compile JSPs in the user codebase. This bug fix ensures that the compiler codebase runs with elevated privileges when compiling JSP files.
13585978	Generated code does not compile when running clientgen/wlsdc for an element of type enum that is using a default value.
13720595	The getTimerService() call in a stateless session Bean PostConstruct method generates an exception.
13742431	A detailed error message or exception trace is needed for Connection Administratively Destroyed issue.
13786287	An incorrect Stax dependency causes a failure in JJava-to-XML conversion.
13806036	If an HTTP client request is corrupted when posting the HTTP body, an ArrayIndexOutOfBoundsException may occur when the application attempts to read from the input stream again after getting an IOException.
13847125	Stuck threads occur at SOAPMessageContext$InvocationPropertyMap.put.
13870996	A ClassNotFoundException occurs when loading a database driver from domain/lib.
13872027	WLDF watch fails when an MBean or MBean attributes are missing at startup. If an attribute is not available on an MBean when the harvester examines it, it is treated as an error, reported, and afterwards ignored.
13919215	Responses contain a carriage return (\r) instead of a line feed (\n).
13973955	When working-dir is set in the JSP description, JSPs are not refreshed when the application is redeployed.
13976683	A java.lang.IndexOutOfBoundsException occurs when a continuation filter such as org.eclipse.jetty.continuation.ContinuationFilter is used.
13987213	An IOException may be generated from the read method on a JSSE socket when an SSL 'close notify' message is received.
14027826	An unlimited number of BasicRuntimeDescriptor and MethodDescriptor instances are created for the Proxy$XXXX class if proxy instances are stored in the JNDI tree and diagnostic images are captured.
14060490	A ClassPathNotFoundException occurs at build time with jwsc (if started from WSDL, that is, jwsc after wsdlc). Classes in the compiled WSDL JAR are not in the classpath when typeFamily is set to XMLBEANS_APACHE.
14115192	Pool connections may leak if remote JDBC is turned off.
14142550	WebLogic Server 10.3.6.0.1 PSU Patch Smart Update Patch ID: JSES

WLS Patch Set Update 10.3.6.0.1
--------------------------------------
9535337		A NullPointerException occurs when logging a cs-uri field of an extended log format if an incorrect HTTP request, which causes a parsing error, is sent.
11926347	An XML signature validation error occurs for a JAX-WS service.
13000612	Policy reference uri validation fails if the uri contains a pound symbol (#) as the leading character.
13092357	If a JSP Document contains a taglib declaration without a prefix (empty p), the corresponding tag library is not interpreted.
13342210	Using WLST to configure max-threads-constraint or min-threads-constraint with a missing or -1 value prevents the server from starting.
13371518	Setting the default compression threshold for a JMS connection factory causes a memory leak.
13416659	WebLogic HTTP handlers do not have an option to switch on/off retyring POST requests. Not having this option causes the WebLogic HTTP Handler to retry an unsuccessful POST request for the value of MAX_RETRIES.
13498960	When performing an overload action, there is a memory leak, as the virtual connection is not closed.
13583235	SU Patch [SLMA]: Tracking bug for WebLogic Security patch 13342292 (cve-2011-5035).
13608597	Environmental information events generated by the JVM when a FlightRecorder snapshot is taken were not enabled at WLDF Off and Low volume settings. These are JVM events that describe, for example, the command line settings, environment variables, and other such events.
13632319	If an application has a very large number of servlets and the JSR 88 API is used to deploy the application, the deploy process may take a significant amount of time to complete.
13646661	Temporary files are not deleted after files are uploaded by deployment. This can cause the temporary space to fill.
13717183	Threads become stuck when sending too many RMI calls.
13787444	A memory leak can occur when running an application that creates and terminates its own threads instead of using a thread pool. For example, the memory leak will not occur if the application is using the Work Manager thread pooling or an application-managed thread pool. The extent of the memory leak depends on how frequently the application is creating/terminating threads.


Oracle recommends that you see following key notes
-----------------------------------------------------------------------------

- My Oracle Support NOTE: 1306505.1 Announcing Oracle WebLogic Server PSUs (Patch Set Updates)
https://support.oracle.com/oip/faces/secure/km/DocumentDisplay.jspx?id=1306505.1 

- My Oracle Support NOTE: 1470197.1 Master Note on WebLogic Server Patch Set Updates (PSUs)
https://support.oracle.com/oip/faces/secure/km/DocumentDisplay.jspx?id=1470197.1

- Known Issues for Oracle WebLogic Server (OWLS) 10.3.6.0.X Patch Set Updates (Doc ID 2137515.1)
https://support.oracle.com/oip/faces/secure/km/DocumentDisplay.jspx?id=2137515.1
 
- My Oracle Support NOTE: 1471192.1 - Replacement Patches for WebLogic Server PSU Conflict Resolution
https://support.oracle.com/oip/faces/secure/km/DocumentDisplay.jspx?id=1471192.1

- SSL Authentication Problem Using WebLogic 10.3.6 and 12.1.1 With JDK1.7.0_40 or Higher
https://support.oracle.com/oip/faces/secure/km/DocumentDisplay.jspx?id=1607170.1
 
- Smart Update Applying Patches to Oracle WebLogic Server 
http://docs.oracle.com/cd/E14759_01/doc.32/e14143/intro.htm 

- If your deployed application uses Java deserialization you may need to customize the WebLogic JEP 290 Default Filter.  
For further information, refer to the "Restrict incoming serialized Java objects." line in the Securing Network Connections table at 
https://docs.oracle.com/middleware/11119/wls/LOCKD/GUID-E5E57EA2-90AC-49E5-AF35-E217B8980BDC.htm#GUID-9A5D9EE1-BE59-475C-BF61-19D4EFC6EDFF

For users of Oracle JDKs and JVMs, we strongly recommend applying the latest
Java Critical Patch Updates (CPUs) as soon as they are released. Refer to the
following for further information:

Doc ID 1506916.1 Obtaining Java SE (JDK/JRE) for Oracle Fusion Middleware Products
https://support.oracle.com/rs?type=doc&id=1506916.1
-----------------------------------------------------------------------------
DISCLAIMER:

Oracle recommends this Patch Set Update (PSU) for development and production systems in accordance with Doc ID 1306505.1. 

This PSU may conflict with an interim patch(es) that has been applied to customer systems. If a patch conflict is identified, customers should determine, through review of the bugs fixed list, whether the interim patch was included in the PSU. If the interim patch is included in the PSU, the interim patch does not need to be applied to systems where the PSU is applied.    If the interim patch is not included in the PSU, the conflict probably arises because the PSU modifies the same module as the interim patch. In such cases, customers should contact Oracle Support, provide information about all patches applied to the system, and request an overlay patch(es) that will resolve the conflict. 

==========================================================================
Copyright © 2019, Oracle and/or its affiliates. All rights reserved.

This software and related documentation are provided under a license agreement containing restrictions on use and disclosure and are protected by intellectual property laws. Except as expressly permitted in your license agreement or allowed by law, you may not use, copy, reproduce, translate, broadcast, modify, license, transmit, distribute, exhibit, perform, publish, or display any part, in any form, or by any means. Reverse engineering, disassembly, or decompilation of this software, unless required by law for interoperability, is prohibited.

The information contained herein is subject to change without notice and is not warranted to be error-free. If you find any errors, please report them to us in writing.

If this software or related documentation is delivered to the U.S. Government or anyone licensing it on behalf of the U.S. Government, the following notice is applicable:

U.S. GOVERNMENT RIGHTS Programs, software, databases, and related documentation and technical data delivered to U.S. Government customers are "commercial computer software" or "commercial technical data" pursuant to the applicable Federal Acquisition Regulation and agency-specific supplemental regulations. As such, the use, duplication, disclosure, modification, and adaptation shall be subject to the restrictions and license terms set forth in the applicable Government contract, and, to the extent applicable by the terms of the Government contract, the additional rights set forth in FAR 52.227-19, Commercial Computer Software License (December 2007). Oracle USA, Inc., 500 Oracle Parkway, Redwood City, CA 94065.

This software is developed for general use in a variety of information management applications. It is not developed or intended for use in any inherently dangerous applications, including applications which may create a risk of personal injury. If you use this software in dangerous applications, then you shall be responsible to take all appropriate fail-safe, backup, redundancy, and other measures to ensure the safe use of this software. Oracle Corporation and its affiliates disclaim any liability for any damages caused by use of this software in dangerous applications.

Oracle is a registered trademark of Oracle Corporation and/or its affiliates. Other names may be trademarks of their respective owners.

This software and documentation may provide access to or information on content, products, and services from third parties. Oracle Corporation and its affiliates are not responsible for and expressly disclaim all warranties of any kind with respect to third-party content, products, and services. Oracle Corporation and its affiliates will not be responsible for any loss, costs, or damages incurred due to your access to or use of third-party content, products, or services.
==========================================================================
