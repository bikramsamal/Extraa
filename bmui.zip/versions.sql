rem connect sys/****** as sysdba
Rem
Rem SQL to display the latest version row record for each product.
Rem The script populates intuse's current_versions table.
Rem 
Rem To convert this to run outside of the New Install
Rem 1. Change the connect to intuse to be general
Rem 2. Look for the
Rem    spool ban_home:[install]initape.ver
Rem    and change it to something that works for your platform.
Rem
whenever sqlerror exit rollback;
set scan on trims on
set showm off heading off veri off feed off echo off timi off time off
rem ALTER PACKAGE sys.dbms_sql COMPILE body;
rem connect system/******
connect baninst1/&&baninst1_password
set scan on trims on
set showm off heading off veri off feed off echo off timi off time off
set linesize 80 pagesize 0 serveroutput on
rem set termout off
column fullcol format a79
whenever sqlerror continue;
BEGIN
   EXECUTE IMMEDIATE 'DROP TABLE current_versions';
EXCEPTION
   WHEN OTHERS THEN
      IF SQLCODE != -942 THEN
         RAISE;
      END IF;
END;
/
whenever sqlerror exit rollback;
CREATE TABLE current_versions (product varchar(33),
                               version varchar(12));
CREATE UNIQUE INDEX current_versions_ndx ON current_versions (product,version);
Rem
Rem Populate current versions table 
Rem
DECLARE
  temp_rel         NUMBER;
  dynamic_string   VARCHAR2(500);
  prod_rel         VARCHAR2(10);
  chk_tab_owner    VARCHAR2(30);
  chk_tab_name     VARCHAR2(30);
  hold_max_rel     NUMBER;
  cursor_num       INTEGER;
  num_rows         INTEGER;
  found_table      VARCHAR2(1);
  CURSOR chk_tab_cursor IS
         SELECT 'Y' 
           FROM DBA_TABLES
          WHERE OWNER       = chk_tab_owner
            AND TABLE_NAME  = chk_tab_name;
--
   TYPE all_rel_info IS RECORD
      (the_table       VARCHAR2(30),
       the_column      VARCHAR2(30),
       the_prod_name   VARCHAR2(33),
       the_prod_code   VARCHAR2(30),
       the_prod_col    VARCHAR2(30),
       the_max_release VARCHAR2(10));
   TYPE all_rel_nos IS TABLE OF all_rel_info
      INDEX BY BINARY_INTEGER;

   prod_cur_rel all_rel_nos;

   rel_ndx BINARY_INTEGER;
   max_ent BINARY_INTEGER;
--
  FUNCTION f_char_to_num (rel_number VARCHAR2)
    RETURN NUMBER IS
  ret_value          NUMBER(10);
  how_big            NUMBER(10);
  uerr_val_too_long  INTEGER := -20101;
  uerr_too_many_dots INTEGER := -20102;
  uerr_not_numeric   INTEGER := -20103;
--
 BEGIN
  IF LENGTH(rel_number) > 10 THEN
     RAISE_APPLICATION_ERROR(uerr_val_too_long,
          'ERROR - Release number can only be 10 positions long.');
     RETURN -1;
  END IF;
--
  IF LENGTH(rel_number) - LENGTH(REPLACE(rel_number,'.')) > 3 THEN
     RAISE_APPLICATION_ERROR(uerr_too_many_dots,
          'ERROR - Too many periods in release number.');
     RETURN -1;
  END IF;
--
  SELECT NVL(LENGTH(REPLACE(TRANSLATE(rel_number,'.0123456789',1),1)),0)
    INTO how_big
    FROM DUAL;
  IF how_big <> 0 THEN
--     RAISE_APPLICATION_ERROR(uerr_not_numeric,
--          'ERROR - Except for periods, release number MUST be numeric.');
     RETURN -1;
  END IF;
--
  SELECT 
  DECODE(LENGTH(rel_number) - LENGTH(REPLACE(rel_number,'.')),
      0,rel_number||'000000',
      1,SUBSTR(rel_number,1,(INSTR(rel_number,'.',1,1)-1))||
        LPAD(SUBSTR(rel_number,(INSTR(rel_number,'.',1,1)+1)),2,0)||'0000',
      2,SUBSTR(rel_number,1,(INSTR(rel_number,'.',1,1)-1))||
        LPAD(SUBSTR(rel_number,
                   (INSTR(rel_number,'.',1,1)+1),
                   (INSTR(rel_number,'.',1,2)-1) -
                   (INSTR(rel_number,'.',1,1))),2,0)||
        LPAD(SUBSTR(rel_number,(INSTR(rel_number,'.',1,2)+1)),2,0)||'00',
      3,SUBSTR(rel_number,1,(INSTR(rel_number,'.',1,1)-1))||
        LPAD(SUBSTR(rel_number,
                   (INSTR(rel_number,'.',1,1)+1),
                   (INSTR(rel_number,'.',1,2)-1) -
                   (INSTR(rel_number,'.',1,1))),2,0)||
        LPAD(SUBSTR(rel_number,
                   (INSTR(rel_number,'.',1,2)+1),
                   (INSTR(rel_number,'.',1,3)-1) -
                   (INSTR(rel_number,'.',1,2))),2,0)||
        LPAD(SUBSTR(rel_number,(INSTR(rel_number,'.',1,3)+1)),2,0)
           ,rel_number
        )
  INTO ret_value
  FROM dual;
  RETURN ret_value;
END f_char_to_num;
--
BEGIN
--
-- Load up our record with all known products and their version table(s)
--
   rel_ndx := 1;
   prod_cur_rel(rel_ndx).the_table      := 'ALUMNI.AURVERS';
   prod_cur_rel(rel_ndx).the_column     := 'AURVERS_RELEASE';
   prod_cur_rel(rel_ndx).the_prod_code  := NULL;
   prod_cur_rel(rel_ndx).the_prod_name  := 'Advancement';
--
   rel_ndx := rel_ndx +1;
   prod_cur_rel(rel_ndx).the_table      := 'TAISMGR.TURVERS';
   prod_cur_rel(rel_ndx).the_column     := 'TURVERS_RELEASE';
   prod_cur_rel(rel_ndx).the_prod_code  := NULL;
   prod_cur_rel(rel_ndx).the_prod_name  := 'Accounts Receivable';
--
   rel_ndx := rel_ndx +1;
   prod_cur_rel(rel_ndx).the_table      := 'BANIMGR.EURVERS';
   prod_cur_rel(rel_ndx).the_column     := 'EURVERS_RELEASE';
   prod_cur_rel(rel_ndx).the_prod_code  := NULL;
   prod_cur_rel(rel_ndx).the_prod_name  := 'XtenderSolutions';
--
   rel_ndx := rel_ndx +1;
   prod_cur_rel(rel_ndx).the_table      := 'FAISMGR.RURVERS';
   prod_cur_rel(rel_ndx).the_column     := 'RURVERS_RELEASE';
   prod_cur_rel(rel_ndx).the_prod_code  := NULL;
   prod_cur_rel(rel_ndx).the_prod_name  := 'Financial Aid';
--
   rel_ndx := rel_ndx +1;
   prod_cur_rel(rel_ndx).the_table      := 'BWRMGR.BWRVERS';
   prod_cur_rel(rel_ndx).the_column     := 'BWRVERS_RELEASE';
   prod_cur_rel(rel_ndx).the_prod_code  := NULL;
   prod_cur_rel(rel_ndx).the_prod_name  := 'Financial Aid Self-service';
--
   rel_ndx := rel_ndx +1;
   prod_cur_rel(rel_ndx).the_table      := 'FIMSMGR.FURVERS';
   prod_cur_rel(rel_ndx).the_column     := 'FURVERS_RELEASE';
   prod_cur_rel(rel_ndx).the_prod_code  := NULL;
   prod_cur_rel(rel_ndx).the_prod_name  := 'Finance';
--
   rel_ndx := rel_ndx +1;
   prod_cur_rel(rel_ndx).the_table      := 'GENERAL.GURVERS';
   prod_cur_rel(rel_ndx).the_column     := 'GURVERS_RELEASE';
   prod_cur_rel(rel_ndx).the_prod_code  := NULL;
   prod_cur_rel(rel_ndx).the_prod_name  := 'General';
--
   rel_ndx := rel_ndx +1;
   prod_cur_rel(rel_ndx).the_table      := 'PAYROLL.PURVERS';
   prod_cur_rel(rel_ndx).the_column     := 'PURVERS_RELEASE';
   prod_cur_rel(rel_ndx).the_prod_code  := NULL;
   prod_cur_rel(rel_ndx).the_prod_name  := 'Human Resources';
--
   rel_ndx := rel_ndx +1;
   prod_cur_rel(rel_ndx).the_table      := 'POSNCTL.NURVERS';
   prod_cur_rel(rel_ndx).the_column     := 'NURVERS_RELEASE';
   prod_cur_rel(rel_ndx).the_prod_code  := NULL;
   prod_cur_rel(rel_ndx).the_prod_name  := 'Position Control';
--
   rel_ndx := rel_ndx +1;
   prod_cur_rel(rel_ndx).the_table      := 'SATURN.SURVERS';
   prod_cur_rel(rel_ndx).the_column     := 'SURVERS_RELEASE';
   prod_cur_rel(rel_ndx).the_prod_code  := NULL;
   prod_cur_rel(rel_ndx).the_prod_name  := 'Student';
--
   rel_ndx := rel_ndx +1;
   prod_cur_rel(rel_ndx).the_table      := 'NLSUSER.TMURVERS';
   prod_cur_rel(rel_ndx).the_column     := 'TMURVERS_RELEASE';
   prod_cur_rel(rel_ndx).the_prod_code  := NULL;
   prod_cur_rel(rel_ndx).the_prod_name  := 'NLS User';
--
   rel_ndx := rel_ndx +1;
   prod_cur_rel(rel_ndx).the_table      := 'WTAILOR.TWGRVERS';
   prod_cur_rel(rel_ndx).the_column     := 'TWGRVERS_RELEASE';
   prod_cur_rel(rel_ndx).the_prod_code  := NULL;
   prod_cur_rel(rel_ndx).the_prod_name  := 'WebTailor';
--
   rel_ndx := rel_ndx +1;
   prod_cur_rel(rel_ndx).the_table      := 'ICMGR.ICVERS';
   prod_cur_rel(rel_ndx).the_column     := 'ICVERS_RELEASE';
   prod_cur_rel(rel_ndx).the_prod_code  := NULL;
   prod_cur_rel(rel_ndx).the_prod_name  := 'Integration Components';
--
   rel_ndx := rel_ndx +1;
   prod_cur_rel(rel_ndx).the_table      := 'VRSMGR.VRSVERS';
   prod_cur_rel(rel_ndx).the_column     := 'VRSVERS_RELEASE';
   prod_cur_rel(rel_ndx).the_prod_code  := NULL;
   prod_cur_rel(rel_ndx).the_prod_name  := 'Voice Response';
--
   rel_ndx := rel_ndx +1;
   prod_cur_rel(rel_ndx).the_table      := 'SATURN.STUVERS';
   prod_cur_rel(rel_ndx).the_column     := 'STUVERS_RELEASE';
   prod_cur_rel(rel_ndx).the_prod_code  := 'Kiosk';
   prod_cur_rel(rel_ndx).the_prod_col   := 'STUVERS_PROD_CODE';
   prod_cur_rel(rel_ndx).the_prod_name  := 'Information Access';
--
   rel_ndx := rel_ndx +1;
   prod_cur_rel(rel_ndx).the_table      := 'BWSMGR.BWSVERS';
   prod_cur_rel(rel_ndx).the_column     := 'BWSVERS_RELEASE';
   prod_cur_rel(rel_ndx).the_prod_code  := NULL;
   prod_cur_rel(rel_ndx).the_prod_name  := 'Student Self-service';
--
   rel_ndx := rel_ndx +1;
   prod_cur_rel(rel_ndx).the_table      := 'BWLMGR.BWLVERS';
   prod_cur_rel(rel_ndx).the_column     := 'BWLVERS_RELEASE';
   prod_cur_rel(rel_ndx).the_prod_code  := NULL;
   prod_cur_rel(rel_ndx).the_prod_name  := 'Faculty and Advisors Self-Service';
--
   rel_ndx := rel_ndx +1;
   prod_cur_rel(rel_ndx).the_table      := 'BWAMGR.BWAVERS';
   prod_cur_rel(rel_ndx).the_column     := 'BWAVERS_RELEASE';
   prod_cur_rel(rel_ndx).the_prod_code  := NULL;
   prod_cur_rel(rel_ndx).the_prod_name  := 'Advancement Self-Service';
--
   rel_ndx := rel_ndx +1;
   prod_cur_rel(rel_ndx).the_table      := 'BWGMGR.BWGVERS';
   prod_cur_rel(rel_ndx).the_column     := 'BWGVERS_RELEASE';
   prod_cur_rel(rel_ndx).the_prod_code  := NULL;
   prod_cur_rel(rel_ndx).the_prod_name  := 'Web General';
--
   rel_ndx := rel_ndx +1;
   prod_cur_rel(rel_ndx).the_table      := 'BWPMGR.BWPVERS';
   prod_cur_rel(rel_ndx).the_column     := 'BWPVERS_RELEASE';
   prod_cur_rel(rel_ndx).the_prod_code  := NULL;
   prod_cur_rel(rel_ndx).the_prod_name  := 'Employees Self-Service';
--
   rel_ndx := rel_ndx +1;
   prod_cur_rel(rel_ndx).the_table      := 'BWFMGR.BWFVERS';
   prod_cur_rel(rel_ndx).the_column     := 'BWFVERS_RELEASE';
   prod_cur_rel(rel_ndx).the_prod_code  := NULL;
   prod_cur_rel(rel_ndx).the_prod_name  := 'Finance Self-Service';
--
   max_ent := rel_ndx;
--
   hold_max_rel := 0;
--
 FOR rel_ndx IN 1..max_ent LOOP
   hold_max_rel := 0;
--
-- First, see if the table exists. Since this is a generic routine, all
-- products (and thus all tables) might not be installed.
--
   chk_tab_owner := substr(prod_cur_rel(rel_ndx).the_table,1,
                     instr(prod_cur_rel(rel_ndx).the_table,'.')-1);
   chk_tab_name  := substr(prod_cur_rel(rel_ndx).the_table,
                     instr(prod_cur_rel(rel_ndx).the_table,'.')+1);
-- dbms_output.put_line('looking for '||chk_tab_owner||'='||chk_tab_name);
   OPEN chk_tab_cursor;
   FETCH chk_tab_cursor
    INTO found_table;
   IF  chk_tab_cursor%NOTFOUND THEN
       CLOSE chk_tab_cursor;
       GOTO end_out_loop;
   END IF;
   CLOSE chk_tab_cursor;
-- dbms_output.put_line('FOUND '||chk_tab_owner||'='||chk_tab_name);
--
-- Select for standard vers tables.
--
   IF prod_cur_rel(rel_ndx).the_prod_code IS NULL THEN
      dynamic_string := 'SELECT '||
                        prod_cur_rel(rel_ndx).the_column||
                        ' from '||
                        prod_cur_rel(rel_ndx).the_table;
--
-- Select for multi product vers tables.
--
  ELSE
      dynamic_string := 'SELECT '||
                        prod_cur_rel(rel_ndx).the_column||
                        ' from '||
                        prod_cur_rel(rel_ndx).the_table||
                        ' where '||
                        prod_cur_rel(rel_ndx).the_prod_col||
                        ' = '||chr(39)||
                        prod_cur_rel(rel_ndx).the_prod_code||chr(39);
  END IF;
   cursor_num := sys.DBMS_SQL.OPEN_CURSOR;
   sys.DBMS_SQL.PARSE(cursor_num,dynamic_string,sys.DBMS_SQL.NATIVE);
   sys.DBMS_SQL.DEFINE_COLUMN(cursor_num,1,prod_rel,10);
   num_rows := sys.DBMS_SQL.EXECUTE(cursor_num);
--
-- Beginning of fetch loop
--
  LOOP
   IF sys.DBMS_SQL.FETCH_ROWS(cursor_num) > 0 THEN
      sys.DBMS_SQL.COLUMN_VALUE(cursor_num,1,prod_rel);
   ELSE
      EXIT;
   END IF;
   temp_rel := f_char_to_num(prod_rel);
   IF temp_rel > hold_max_rel THEN
      hold_max_rel := temp_rel;
      prod_cur_rel(rel_ndx).the_max_release := prod_rel;
   END IF;
  END LOOP;
--
-- End of fetch loop
--
   insert into current_versions (product, version)
        values (prod_cur_rel(rel_ndx).the_prod_name,
                prod_cur_rel(rel_ndx).the_max_release);
--
--   DBMS_OUTPUT.PUT_LINE(rpad(prod_cur_rel(rel_ndx).the_prod_name,22)||' = '||
--                        prod_cur_rel(rel_ndx).the_max_release);
   sys.DBMS_SQL.CLOSE_CURSOR(cursor_num);
<< end_out_loop >>
   NULL;
 END LOOP;
END;
/
set termout on
spool prodver.lis
select '                       Product Release List' fullcol,
       '               -----------------------------------------' fullcol
  from dual;
rem
select '               ' || product, version
  from current_versions
 order by product;
rem select '                       ' || 
rem        'baninas' || ':  ' || version 
rem   from current_versions where product = 'FINAID';
spool off
REM spool ban_home:[install]initape.ver
spool genver
select '                      Banner New Installation' fullcol,
       '                         Media Code XXXXX' fullcol,
       '                       Product Release List' fullcol,
       '               -----------------------------------------' fullcol
  from dual;
select '               ' || product, version
  from current_versions
 order by product;
rem select '                       ' || 
rem        'baninas' || ':  ' || version 
rem   from current_versions where product = 'FINAID';
spool off
exit
